package com.example.cw1601_java;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class DataValidations {
    public static boolean textFieldIsNull(TextField inputTextField, Label inputLabel, String validationText ) {
        boolean isNull = false;
        String validationString = null;

        if (inputTextField.getText().isEmpty()) {
            isNull = true;
            validationString = validationText;
        }

        inputLabel.setText(validationString);
        return isNull;
    }
}
